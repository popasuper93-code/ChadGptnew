package app.chadgpt.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.InputType;
import android.text.method.LinkMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ChadGPT — нативное приложение. Экраны нарисованы здесь же, а ответы ИИ приходят с вашего сервера.
 * Если адрес сервера поменяется — исправьте BASE ниже.
 */
public class MainActivity extends Activity {

    static final String BASE = "https://chadgpt.wisp.uno";

    static final int BG = 0xFF0D0E1C, CARD = 0xFF1A1C33, ACC = 0xFFB8F53D, TXT = 0xFFEEF0FF,
            MUTED = 0xFF9AA0C4, UBUB = 0xFF2B2F55, ON_ACC = 0xFF10130A;
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    static class Resp {
        int code;
        JSONObject json = new JSONObject();
    }

    static class Msg {
        LinearLayout box;
        TextView tv;
    }

    final ExecutorService io = Executors.newCachedThreadPool();
    final Handler ui = new Handler(Looper.getMainLooper());
    SharedPreferences sp;
    FrameLayout root;
    String session;
    JSONObject me = new JSONObject();
    String level = "flow";

    LinearLayout log, lastFooter;
    ScrollView scroll;
    EditText input;
    TextView sendBtn, tokensView, levelBtn;
    View lastUserBubble;
    Msg curPend;
    String lastUserText = "";
    boolean busy;
    String rid = "";

    // ───────────────────────── запуск ─────────────────────────
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("chadgpt", MODE_PRIVATE);
        session = sp.getString("s", null);
        try {
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
        } catch (Exception ignored) {
        }
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets sb = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = ins.getInsets(WindowInsets.Type.ime());
                top = sb.top;
                bottom = Math.max(sb.bottom, ime.bottom);
            } else {
                top = ins.getSystemWindowInsetTop();
                bottom = ins.getSystemWindowInsetBottom();
            }
            v.setPadding(0, top, 0, bottom);
            return ins;
        });
        setContentView(root);
        if (session == null) showLogin();
        else loadMe(false, null);
    }

    // ───────────────────────── сеть ─────────────────────────
    Resp post(String path, JSONObject body) {
        Resp r = new Resp();
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BASE + path).openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(180000);
            c.setRequestProperty("Content-Type", "application/json");
            if (session != null) c.setRequestProperty("X-Session", session);
            c.setDoOutput(true);
            byte[] data = (body == null ? new JSONObject() : body).toString().getBytes("UTF-8");
            c.setFixedLengthStreamingMode(data.length);
            try (OutputStream o = c.getOutputStream()) {
                o.write(data);
            }
            r.code = c.getResponseCode();
            InputStream is = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
            String s = is == null ? "" : readAll(is);
            try {
                r.json = new JSONObject(s);
            } catch (Exception e) {
                r.json = new JSONObject();
            }
        } catch (Exception e) {
            r.code = 0;
        } finally {
            if (c != null) c.disconnect();
        }
        return r;
    }

    static String readAll(InputStream is) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    static JSONObject j(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
        } catch (JSONException ignored) {
        }
        return o;
    }

    // ───────────────────────── помощники интерфейса ─────────────────────────
    int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    TextView pill(String s) {
        TextView t = text(s, 16, ON_ACC, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(20), dp(13), dp(20), dp(13));
        t.setBackground(rounded(ACC, 26));
        t.setClickable(true);
        return t;
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    void open(String path) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(path.startsWith("http") ? path : BASE + path)));
        } catch (Exception e) {
            toast("Не удалось открыть ссылку");
        }
    }

    void scrollDown() {
        if (scroll != null) scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    static String fmt(long n) {
        return n >= 1000 ? String.format(Locale.US, "%.1fk", n / 1000.0) : String.valueOf(n);
    }

    static String cleanText(String s) {
        s = s.replaceAll("```[A-Za-z0-9+#._-]*[ \\t]*\\n?", "");
        s = s.replace("**", "").replaceAll("(?m)^#{1,6}\\s*", "").replaceAll("\\[\\[img:[^\\]]*\\]\\]\\s*", "🖼 ");
        return s.trim();
    }

    String hm(long sec) {
        long h = sec / 3600, m = (sec % 3600) / 60;
        return h > 0 ? h + " ч " + m + " мин" : Math.max(1, m) + " мин";
    }

    // ───────────────────────── экран входа ─────────────────────────
    void showLogin() {
        session = null;
        sp.edit().remove("s").apply();
        root.removeAllViews();
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(28), dp(28), dp(28), dp(28));

        TextView logo = text("ChadGPT", 36, ACC, true);
        logo.setGravity(Gravity.CENTER);
        TextView sub = text("ИИ-ассистент: чат, код, картинки и файлы", 15, MUTED, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(8), 0, dp(36));
        final TextView btn = pill("Продолжить как гость");
        TextView legal = new TextView(this);
        legal.setTextSize(12.5f);
        legal.setTextColor(MUTED);
        legal.setLinkTextColor(ACC);
        legal.setGravity(Gravity.CENTER);
        legal.setPadding(0, dp(22), 0, 0);
        legal.setMovementMethod(LinkMovementMethod.getInstance());
        legal.setText(Html.fromHtml("Гостевой аккаунт привязан к этому устройству. Ответы создаёт ИИ и могут содержать ошибки. "
                + "Продолжая, вы принимаете <a href=\"" + BASE + "/terms\">условия</a> и <a href=\"" + BASE
                + "/privacy\">политику конфиденциальности</a>.", Html.FROM_HTML_MODE_LEGACY));

        c.addView(logo, new LinearLayout.LayoutParams(MATCH, WRAP));
        c.addView(sub, new LinearLayout.LayoutParams(MATCH, WRAP));
        c.addView(btn, new LinearLayout.LayoutParams(MATCH, WRAP));
        c.addView(legal, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(c, new FrameLayout.LayoutParams(MATCH, MATCH));

        btn.setOnClickListener(v -> {
            btn.setEnabled(false);
            btn.setAlpha(0.5f);
            io.execute(() -> {
                Resp r = post("/api/guest_login", null);
                ui.post(() -> {
                    String s = r.json.optString("session", "");
                    if (r.code == 200 && !s.isEmpty()) {
                        session = s;
                        sp.edit().putString("s", s).apply();
                        loadMe(false, null);
                    } else {
                        btn.setEnabled(true);
                        btn.setAlpha(1f);
                        toast(r.code == 429 ? "Слишком часто, попробуй позже" : "Не удалось войти. Проверь интернет");
                    }
                });
            });
        });
    }

    void showRetry() {
        root.removeAllViews();
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(28), dp(28), dp(28), dp(28));
        TextView t = text("Нет связи с сервером", 18, TXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 0, 0, dp(20));
        TextView b = pill("Повторить");
        b.setOnClickListener(v -> loadMe(false, null));
        c.addView(t, new LinearLayout.LayoutParams(MATCH, WRAP));
        c.addView(b, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(c, new FrameLayout.LayoutParams(MATCH, MATCH));
    }

    void loadMe(final boolean silent, final Runnable after) {
        io.execute(() -> {
            Resp r = post("/api/me", null);
            ui.post(() -> {
                if (r.code == 401) {
                    showLogin();
                } else if (r.code == 200) {
                    me = r.json;
                    level = me.optString("mode", "flow");
                    if (silent) updateTop();
                    else showChat();
                    if (me.optBoolean("banned")) toast("Аккаунт заблокирован");
                    if (after != null) after.run();
                } else if (!silent) {
                    showRetry();
                } else if (after != null) {
                    after.run();
                }
            });
        });
    }

    // ───────────────────────── экран чата ─────────────────────────
    String levelName(String key) {
        JSONArray a = me.optJSONArray("levels");
        if (a != null) {
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null && key.equals(o.optString("key"))) return o.optString("name", key);
            }
        }
        return key;
    }

    void updateTop() {
        if (tokensView == null) return;
        tokensView.setText(me.optBoolean("premium") ? "Премиум ∞" : "🪙 " + fmt(me.optLong("left", 0)));
        levelBtn.setText(levelName(level) + "  ▾");
    }

    void showChat() {
        root.removeAllViews();
        busy = false;
        rid = "";
        lastFooter = null;
        lastUserBubble = null;

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(16), dp(8), dp(6), dp(4));
        TextView title = text("ChadGPT", 21, ACC, true);
        tokensView = text("", 13, TXT, false);
        tokensView.setPadding(dp(12), dp(7), dp(12), dp(7));
        tokensView.setBackground(rounded(CARD, 16));
        TextView menu = text("⋮", 28, TXT, true);
        menu.setPadding(dp(14), dp(2), dp(14), dp(2));
        menu.setOnClickListener(v -> showMenu());
        top.addView(title, new LinearLayout.LayoutParams(0, WRAP, 1f));
        top.addView(tokensView, new LinearLayout.LayoutParams(WRAP, WRAP));
        top.addView(menu, new LinearLayout.LayoutParams(WRAP, WRAP));

        levelBtn = text("", 14.5f, TXT, true);
        levelBtn.setPadding(dp(16), dp(10), dp(16), dp(10));
        levelBtn.setBackground(rounded(CARD, 18));
        levelBtn.setOnClickListener(v -> pickLevel());
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(WRAP, WRAP);
        llp.leftMargin = dp(16);
        llp.topMargin = dp(4);
        llp.bottomMargin = dp(4);

        scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        log = new LinearLayout(this);
        log.setOrientation(LinearLayout.VERTICAL);
        log.setPadding(dp(12), dp(6), dp(12), dp(10));
        scroll.addView(log, new ViewGroup.LayoutParams(MATCH, WRAP));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.BOTTOM);
        bar.setPadding(dp(10), dp(6), dp(10), dp(10));
        input = new EditText(this);
        input.setHint("Спроси что угодно или «нарисуй…»");
        input.setHintTextColor(MUTED);
        input.setTextColor(TXT);
        input.setTextSize(15.5f);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setMaxLines(5);
        input.setBackground(rounded(CARD, 22));
        input.setPadding(dp(16), dp(12), dp(16), dp(12));
        sendBtn = pill("➤");
        sendBtn.setPadding(dp(18), dp(12), dp(18), dp(12));
        sendBtn.setOnClickListener(v -> send(false));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        ilp.rightMargin = dp(8);
        bar.addView(input, ilp);
        bar.addView(sendBtn, new LinearLayout.LayoutParams(WRAP, WRAP));

        col.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));
        col.addView(levelBtn, llp);
        col.addView(scroll, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        col.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));
        updateTop();

        JSONArray h = me.optJSONArray("history");
        if (h == null || h.length() == 0) {
            addBubble("Здорово. Что делаем? Выбери уровень сверху или просто пиши.", false);
        } else {
            for (int i = 0; i < h.length(); i++) {
                JSONObject o = h.optJSONObject(i);
                if (o == null) continue;
                boolean user = "u".equals(o.optString("r"));
                String raw = o.optString("t");
                Msg m = addBubble(cleanText(raw), user);
                if (!user) {
                    boolean cut = i == h.length() - 1 && raw.contains("Когда токены обновятся, нажми");
                    addFooter(m, false, 0);
                    if (cut) addMore(lastFooter);
                }
            }
        }
        scrollDown();
    }

    Msg addBubble(String t, boolean user) {
        Msg m = new Msg();
        m.box = new LinearLayout(this);
        m.box.setOrientation(LinearLayout.VERTICAL);
        m.box.setPadding(dp(13), dp(10), dp(13), dp(10));
        m.box.setBackground(rounded(user ? UBUB : CARD, 18));
        m.tv = new TextView(this);
        m.tv.setText(t);
        m.tv.setTextColor(TXT);
        m.tv.setTextSize(15.5f);
        m.tv.setLineSpacing(0, 1.15f);
        m.tv.setTextIsSelectable(true);
        m.tv.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.86f) - dp(26));
        m.box.addView(m.tv, new LinearLayout.LayoutParams(WRAP, WRAP));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        lp.topMargin = dp(6);
        lp.bottomMargin = dp(2);
        lp.gravity = user ? Gravity.END : Gravity.START;
        log.addView(m.box, lp);
        scrollDown();
        return m;
    }

    TextView small(String label, View.OnClickListener l) {
        TextView t = text(label, 12.5f, MUTED, false);
        t.setPadding(0, dp(4), dp(16), dp(4));
        t.setOnClickListener(l);
        return t;
    }

    void addFooter(final Msg m, boolean more, long cost) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.HORIZONTAL);
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(0, dp(6), 0, 0);
        f.addView(small("Копия", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("ChadGPT", m.tv.getText().toString()));
            toast("Скопировано");
        }));
        f.addView(small("Жалоба", v -> report(m.tv.getText().toString())));
        if (cost > 0) f.addView(small("−" + fmt(cost), null));
        m.box.addView(f, new LinearLayout.LayoutParams(WRAP, WRAP));
        lastFooter = f;
        if (more) addMore(f);
    }

    void addMore(final LinearLayout f) {
        if (f == null) return;
        TextView t = text("Продолжить ▸", 13, ACC, true);
        t.setTag("more");
        t.setPadding(0, dp(4), 0, dp(4));
        t.setOnClickListener(v -> send(true));
        f.addView(t);
    }

    void removeMore(LinearLayout f) {
        if (f == null) return;
        for (int i = f.getChildCount() - 1; i >= 0; i--) {
            if ("more".equals(f.getChildAt(i).getTag())) f.removeViewAt(i);
        }
    }

    // ───────────────────────── отправка и ответ ─────────────────────────
    void send(final boolean cont) {
        if (busy) {
            stop();
            return;
        }
        final String t = input.getText().toString().trim();
        if (!cont && t.isEmpty()) return;
        if (!cont) {
            lastUserBubble = addBubble(t, true).box;
            lastUserText = t;
            input.setText("");
        } else {
            removeMore(lastFooter);
        }
        busy = true;
        sendBtn.setText("■");
        final Msg pend = addBubble("Думаю…", false);
        curPend = pend;
        final String myRid = Long.toString(System.nanoTime(), 36);
        rid = myRid;
        final boolean staged = level.equals("omega") || level.equals("chadex");
        final JSONObject body = j("text", cont ? "" : t, "cont", cont, "level", level, "rid", myRid);
        io.execute(() -> {
            Resp r = post("/api/chat", body);
            ui.post(() -> onReply(pend, r, t, cont, myRid));
        });
        if (staged) ui.postDelayed(() -> poll(pend, myRid), 2500);
    }

    void poll(final Msg pend, final String myRid) {
        if (!busy || !myRid.equals(rid)) return;
        io.execute(() -> {
            Resp p = post("/api/progress", j("rid", myRid));
            ui.post(() -> {
                if (!busy || !myRid.equals(rid)) return;
                String st = p.json.optString("stage", "");
                if (!st.isEmpty()) {
                    String tx = p.json.optString("text", "");
                    pend.tv.setText(st + (tx.isEmpty() ? "" : "\n\n" + cleanText(tx)));
                    scrollDown();
                }
                ui.postDelayed(() -> poll(pend, myRid), 2000);
            });
        });
    }

    void stop() {
        final String old = rid;
        rid = "";
        busy = false;
        sendBtn.setText("➤");
        io.execute(() -> post("/api/cancel", j("rid", old)));
        if (curPend != null) log.removeView(curPend.box);
        if (lastUserBubble != null) {
            log.removeView(lastUserBubble);
            lastUserBubble = null;
            input.setText(lastUserText);
        }
        toast("Остановлено");
    }

    void onReply(Msg pend, Resp r, String t, boolean cont, String myRid) {
        if (!myRid.equals(rid)) return; // ответ уже отменён кнопкой «стоп»
        busy = false;
        rid = "";
        sendBtn.setText("➤");
        JSONObject d = r.json;
        String kind = d.optString("kind", "");
        if (r.code == 200 && !"canceled".equals(kind)) {
            if (d.has("left")) {
                try {
                    me.put("left", d.optLong("left"));
                } catch (JSONException ignored) {
                }
                updateTop();
            }
            if ("image".equals(kind)) showImage(pend, d);
            else showAnswer(pend, d);
            return;
        }
        log.removeView(pend.box);
        if (!cont && lastUserBubble != null) {
            log.removeView(lastUserBubble);
            lastUserBubble = null;
            input.setText(t);
        }
        if (cont) addMore(lastFooter);
        String e = d.optString("error", "");
        if (r.code == 401) {
            toast("Сессия истекла, войди заново");
            showLogin();
        } else if (r.code == 402 || "limit".equals(e)) {
            loadMe(true, () -> toast("Токены закончились. Бесплатные вернутся через " + hm(me.optLong("reset_in", 25200))
                    + " — потом нажми «Продолжить»."));
        } else if ("busy".equals(e) || r.code == 429) {
            toast("Подожди, я ещё отвечаю на прошлый запрос");
        } else if (r.code == 0) {
            toast("Нет связи с сервером");
        } else if (d.has("message")) {
            toast(d.optString("message"));
        } else {
            toast("Ошибка, попробуй ещё раз");
        }
    }

    void showAnswer(Msg pend, JSONObject d) {
        pend.tv.setText(cleanText(d.optString("answer", "")));
        JSONArray fs = d.optJSONArray("files");
        if (fs != null) {
            for (int i = 0; i < fs.length(); i++) {
                JSONObject f = fs.optJSONObject(i);
                if (f == null) continue;
                final String url = f.optString("url");
                TextView ft = text("📄 " + f.optString("name") + "  ·  скачать", 14, ACC, true);
                ft.setPadding(0, dp(8), 0, dp(2));
                ft.setOnClickListener(v -> open(url));
                pend.box.addView(ft);
            }
        }
        addFooter(pend, d.optBoolean("more"), d.optLong("cost"));
        scrollDown();
    }

    void showImage(Msg pend, JSONObject d) {
        pend.tv.setText("«" + d.optString("caption", "") + "»");
        final String url = d.optString("url");
        final ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setOnClickListener(v -> open(url));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(270), WRAP);
        lp.topMargin = dp(8);
        pend.box.addView(iv, lp);
        io.execute(() -> {
            try {
                String u = url.startsWith("http") ? url : BASE + url;
                Bitmap bmp = BitmapFactory.decodeStream(new URL(u).openStream());
                ui.post(() -> {
                    if (bmp != null) iv.setImageBitmap(bmp);
                    scrollDown();
                });
            } catch (Exception ignored) {
            }
        });
        addFooter(pend, false, d.optLong("cost"));
    }

    // ───────────────────────── меню, уровни, жалобы, удаление ─────────────────────────
    void pickLevel() {
        final JSONArray a = me.optJSONArray("levels");
        if (a == null || a.length() == 0) return;
        final String[] items = new String[a.length()];
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            items[i] = o.optString("name") + " · " + o.optString("sub") + " ×" + o.optString("mult") + "\n" + o.optString("desc");
        }
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Уровень ответа")
                .setItems(items, (dlg, which) -> {
                    final JSONObject o = a.optJSONObject(which);
                    final String key = o.optString("key");
                    io.execute(() -> {
                        Resp r = post("/api/mode", j("mode", key));
                        ui.post(() -> {
                            if (r.code == 200) {
                                level = key;
                                updateTop();
                                toast("Уровень: " + o.optString("name"));
                            } else {
                                toast("Не получилось сменить уровень");
                            }
                        });
                    });
                }).show();
    }

    void showMenu() {
        final String[] items = {"Новый чат", "Политика конфиденциальности", "Условия использования", "Удалить аккаунт", "Выйти"};
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setItems(items, (dlg, which) -> {
                    if (which == 0) newChat();
                    else if (which == 1) open("/privacy");
                    else if (which == 2) open("/terms");
                    else if (which == 3) confirmDelete();
                    else confirmLogout();
                }).show();
    }

    void newChat() {
        io.execute(() -> {
            Resp r = post("/api/reset", null);
            ui.post(() -> {
                if (r.code == 200) {
                    log.removeAllViews();
                    lastFooter = null;
                    addBubble("Новый чат. О чём поговорим?", false);
                } else {
                    toast("Не получилось");
                }
            });
        });
    }

    void confirmLogout() {
        String msg = me.optBoolean("guest")
                ? "Гостевой аккаунт привязан к этому устройству. После выхода переписка и токены будут недоступны. Выйти?"
                : "Выйти из аккаунта?";
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setMessage(msg)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Выйти", (dlg, w) -> {
                    io.execute(() -> post("/api/logout", null));
                    showLogin();
                }).show();
    }

    void confirmDelete() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Удалить аккаунт?")
                .setMessage("Будут безвозвратно удалены переписка, баланс токенов, подписка и настройки. Оплаченное не возвращается. Отменить нельзя.")
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Удалить навсегда", (dlg, w) -> io.execute(() -> {
                    Resp r = post("/api/delete_account", j("confirm", true));
                    ui.post(() -> {
                        if (r.code == 200) {
                            toast("Аккаунт удалён");
                            showLogin();
                        } else if (r.code == 403) {
                            toast("Недоступно для этого аккаунта");
                        } else {
                            toast("Не удалось удалить, попробуй ещё раз");
                        }
                    });
                })).show();
    }

    void report(final String text) {
        final String[] reasons = {"Опасный или вредный", "Оскорбительный", "Неверный", "Другое"};
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Пожаловаться на ответ")
                .setItems(reasons, (dlg, which) -> io.execute(() -> {
                    String t = text.length() > 1500 ? text.substring(0, 1500) : text;
                    Resp r = post("/api/report", j("text", t, "reason", reasons[which]));
                    ui.post(() -> toast(r.code == 200 ? "Спасибо, жалоба отправлена" : "Не удалось отправить"));
                })).show();
    }
}
