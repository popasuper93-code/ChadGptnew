package app.chadgpt.android;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * ChadGPT. Интерфейс (тот же, что на сайте и в Telegram-мини-аппе) лежит внутри приложения: app/src/main/assets/index.html.
 * Ответы ИИ приходят с вашего сервера. Если адрес сервера поменяется — исправьте BASE и пересоберите.
 */
public class MainActivity extends Activity {

    static final String BASE = "https://chadgpt.wisp.uno";
    static final int BG = 0xFF0D0E1C;
    static final int FILE_REQ = 7;

    WebView web;
    ValueCallback<Uri[]> chooser;
    SharedPreferences sp;

    /** Мост для страницы: сохранить сессию (чтобы гость не терял аккаунт) и открыть ссылку в браузере. */
    class Bridge {
        @JavascriptInterface
        public void save(String k, String v) {
            sp.edit().putString(k, v).apply();
        }

        @JavascriptInterface
        public String load(String k) {
            return sp.getString(k, "");
        }

        @JavascriptInterface
        public void openUrl(final String u) {
            runOnUiThread(() -> open(u));
        }
    }

    void open(String u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u.startsWith("http") ? u : BASE + u)));
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("chadgpt", MODE_PRIVATE);
        try {
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
        } catch (Exception ignored) {
        }
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        root.setOnApplyWindowInsetsListener((v, ins) -> {
            int top, bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets sb = ins.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = ins.getInsets(WindowInsets.Type.ime());
                top = sb.top;
                bottom = Math.max(sb.bottom, ime.bottom);
            } else {
                top = ins.getSystemWindowInsetTop();
                bottom = ins.getSystemWindowInsetBottom();
            }
            v.setPadding(0, top, 0, bottom);
            return ins;
        });

        web = new WebView(this);
        web.setBackgroundColor(BG);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);
        web.addJavascriptInterface(new Bridge(), "AndroidApp");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                open(r.getUrl().toString()); // любые ссылки (политика, Telegram, скачивание) — во внешнем браузере
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = cb;
                try {
                    startActivityForResult(p.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    chooser = null;
                    return false;
                }
                return true;
            }
        });

        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        String html = "";
        try (InputStream is = getAssets().open("index.html")) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            html = bo.toString("UTF-8");
        } catch (Exception e) {
            Toast.makeText(this, "Не удалось загрузить интерфейс", Toast.LENGTH_LONG).show();
        }
        web.loadDataWithBaseURL(BASE + "/", html, "text/html", "UTF-8", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            chooser = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
